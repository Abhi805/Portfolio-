const BagSummary = ({summary}) =>{

const bagSummary ={
    totalItem:3,
    totalMRP:2345,
    totalDiscount:999,
    finalPayment:1346
}

    return(
        <>
        <div classname="bag-details-container">
        <div classname="price-header">PRICE DETAILS ({bagSummary.totalItem} Items) </div>
        <div classname="price-item">
          <span classname="price-item-tag">Total MRP</span>
          <span classname="price-item-value">₹${totalMRP}</span>
        </div>
        <div classname="price-item">
          <span classname="price-item-tag">Discount on MRP</span>

          <span classname="price-item-value priceDetail-base-discount">{bagSummary.totalDiscount}</span>
        </div>
        <div classname="price-item">
          <span classname="price-item-tag">Convenience Fee</span>
          <span classname="price-item-value">₹99</span>
        </div>
        <hr/>
        <div classname="price-footer">
          <span classname="price-item-tag">Total Amount</span>
          <span classname="price-item-value">₹${bagSummary.finalPayment}</span>
        </div>
      </div>
      <button classname="btn-place-order">
        <div classname="css-xjhrni">PLACE ORDER</div>
      </button>
        </>
        
    )
}

export default BagSummary;